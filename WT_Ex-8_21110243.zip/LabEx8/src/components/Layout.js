import React, { useState } from "react";
import { Outlet, Link } from "react-router-dom";
import "./layout.css";
import logoImage from "./logo.png";
import logoImage2 from "./logo2.png";

const Layout = () => {
  const [showHomeDropdown, setShowHomeDropdown] = useState(false);
  const [showBlogsDropdown, setShowBlogsDropdown] = useState(false);
  const [showContactDropdown, setShowContactDropdown] = useState(false);
  const [showAboutDropdown, setShowAboutDropdown] = useState(false);
  const [showCareersDropdown, setShowCareersDropdown] = useState(false);

  const toggleHomeDropdown = () => {
    setShowHomeDropdown(!showHomeDropdown);
    setShowBlogsDropdown(false);
    setShowContactDropdown(false);
    setShowAboutDropdown(false);
    setShowCareersDropdown(false);
  };

  const toggleBlogsDropdown = () => {
    setShowBlogsDropdown(!showBlogsDropdown);
    setShowHomeDropdown(false);
    setShowContactDropdown(false);
    setShowAboutDropdown(false);
    setShowCareersDropdown(false);
  };

  const toggleContactDropdown = () => {
    setShowContactDropdown(!showContactDropdown);
    setShowHomeDropdown(false);
    setShowBlogsDropdown(false);
    setShowAboutDropdown(false);
    setShowCareersDropdown(false);
  };

  const toggleCareersDropdown = () => {
    setShowCareersDropdown(!showCareersDropdown);
    setShowHomeDropdown(false);
    setShowContactDropdown(false);
    setShowBlogsDropdown(false);
    setShowAboutDropdown(false);
  };

  const toggleAboutDropdown = () => {
    setShowAboutDropdown(!showAboutDropdown);
    setShowHomeDropdown(false);
    setShowContactDropdown(false);
    setShowBlogsDropdown(false);
    setShowCareersDropdown(false);
  };
  return (
    <>
      <nav>
      <table className="nav-list">
        <tr>
          <div className="logo-container">
            <img src={logoImage} alt="Logo" className="logo-image" />
          </div>
          <td className="dropdown">
            <Link to="/" className="nav-link" onClick={toggleHomeDropdown}>Who we are</Link>
          </td>
          <td className="dropdown">
            <Link to="/Blogs" className="nav-link" onClick={toggleBlogsDropdown}>What we do</Link>
          </td>
          <td className="dropdown">
            <Link to="/Contact" className="nav-link" onClick={toggleContactDropdown}>News</Link>
          </td>
          <td className="dropdown">
            <Link to="/Careers" className="nav-link" onClick={toggleCareersDropdown}>Investors</Link>
          </td>
          <td className="dropdown">
            <Link to="/About" className="nav-link" onClick={toggleAboutDropdown}>Careers</Link>
          </td>
          <div className="logo-container">
            <img src={logoImage2} alt="Logo" className="logo-image" />
          </div>
        </tr>
      </table>
      </nav>
      <Outlet />
    </>
  );
};

export default Layout;