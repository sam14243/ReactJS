import React, { useState } from "react";
import { Outlet, Link } from "react-router-dom";
import "./layout.css";

const Investors = (props) => {
  const { someProp } = props;
    return (
      <div style={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center'}}>  
        <h1>Number of Investors we have: {someProp} </h1> 
      </div>
    );
  };
  
  export default Investors;