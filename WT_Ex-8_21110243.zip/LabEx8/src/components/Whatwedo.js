import React, { useState } from "react";
import { Outlet, Link } from "react-router-dom";
import "./layout.css";
import Button from 'react-bootstrap/Button';

const Whatwedo = () => {
  const [counter, setCounter] = useState(0)

  const increment = () => {
    setCounter(counter+1)
  }
  const decrement = () => {
    setCounter(counter-1)
  }
  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center'}}>  
      <h1>We count numbers!!</h1>  
      <div style={{fontSize: '40px'}}>{counter}</div>
      <div><button className="btn btn-success" onClick = {increment}>Increment</button></div>
      <div><button className="btn btn-danger" onClick = {decrement}>Decrement</button></div>
    </div>
  );
};

export default Whatwedo;
