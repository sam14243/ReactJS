import ReactDOM from "react-dom/client";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Layout from "./components/Layout";
import Whoweare from "./components/Whoweare";
import Whatwedo from "./components/Whatwedo";
import News from "./components/News";
import Careers from "./components/Careers";
import Investors from "./components/Investors";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Whoweare/>} />
          <Route path="/Whatwedo" element={<Whatwedo />} />
          <Route path="/News" element={<News />} />
          <Route path="/Careers" element={<Careers />} />
          <Route path="/Investors" element={<Investors someProp="69420" />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);